﻿namespace Library_POE_PART_1
{
    public static class Calculate
    {
        public static int CalcHoursPerWeek(int credits, int weeks, int classHrs)
        {
            int HrsPerWeek;
            HrsPerWeek = (int)Math.Round(((double)(credits * 10) / weeks) - classHrs, MidpointRounding.AwayFromZero);
            return HrsPerWeek;
        }
        public static int currentWeek(DateTime startDate)
        {
            int currentWeek;
            currentWeek = (int)Math.Ceiling(((DateTime.Now - startDate).TotalDays + 1) / 7);
            return currentWeek;
        }
        public static int workWeek(DateTime workDate, DateTime startDate)
        {
            int workWeek;
            workWeek = (int)Math.Ceiling(((workDate - startDate).TotalDays + 1) / 7);
            return workWeek;
        }

    }
    public class Module
    {
        public string code { get; set; }
        public string name { get; set; }
        public int credits { get; set; }
        public int classHrs { get; set; }
        public int HrsPerWeek { get; set; }

        public int numWeeks { get; set; }

        public DateTime startDate { get; set; }
        public int hoursRemaining { get; set; }
        public int hoursSpentThisWeek { get; set; }



        // default constructor
        public Module() { }

        public Module(string code, string name, int credits, int classHrs, int hrsPerWeek, DateTime startDate)
        {
            this.code = code;
            this.name = name;
            this.credits = credits;
            this.classHrs = classHrs;
            this.HrsPerWeek = hrsPerWeek;
            this.numWeeks = numWeeks;
            this.startDate = startDate;

        }

     }

    public class Study
    {
        public string Code { get; set; } 

        public DateTime studyDate { get; set; }

        public int hrsWorked { get; set; }

    }
                  
}