﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Library_POE_PART_1;

namespace PROG_Poe_Task1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Instance
        Module temp = new Module();
        Study studies = new Study();

        //Lists Of T to store variables
        List<Study> studyData = new List<Study>();
        List<Module> course = new List<Module>();
        List<Module> hours = new List<Module>();
        List<Module> filtered;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void tb1Add_Click(object sender, RoutedEventArgs e)
        {
            if (tbName.Text.Length == 0 ||
                tb1Code.Text.Length == 0 || tbCredits.Text.Length == 0)

            {
                MessageBox.Show("Fields Can Not Be Left Blank");
            }
            else
            {
                if (MessageBox.Show("Is The Entry Correct? ", "Confirm Entry", MessageBoxButton.YesNo)
                    == MessageBoxResult.Yes)
                {
                    //Gettng values from textboxes
                    temp.name = tbName.Text;
                    temp.code = tb1Code.Text;
                    temp.credits = Convert.ToInt32(tbCredits.Text);
                    temp.classHrs = Convert.ToInt32(tbClassHrs.Text);
                    temp.numWeeks = Convert.ToInt32(tbWeeks.Text);
                    temp.startDate = DateTime.Parse(DatePicker2.Text);
                    temp.HrsPerWeek = Calculate.CalcHoursPerWeek(temp.credits, temp.numWeeks, temp.classHrs);

                    temp.hoursSpentThisWeek = 0;
                    temp.hoursRemaining = temp.HrsPerWeek;
            
                    course.Add(new Module { name = temp.name, code = temp.code, credits = temp.credits, classHrs = temp.classHrs, numWeeks = temp.numWeeks, startDate = temp.startDate, HrsPerWeek = temp.HrsPerWeek });
                    hours.Add(new Module { code = temp.code, hoursSpentThisWeek = temp.hoursSpentThisWeek, hoursRemaining = temp.hoursRemaining });
                   

                    DataGrid1.Items.Clear();
                    //Displaying the users input in the first datagrid
                    foreach (Module m in course)
                    {
                        DataGrid1.Items.Add(m);
                    }

                    tbName.Clear();
                    tb1Code.Clear();
                    tbCredits.Clear();
                    tbClassHrs.Clear();
                    tbWeeks.Clear();
                    

                }
            }
            
        }

        private void tb1Help_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Enter All The Information Above Then Click On Add Course!!!! ");
        }

        private void tb2Help_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Enter All The Information Above Then Click On Add Hours!!!! ");

        }

        private void tb2Add_Click(object sender, RoutedEventArgs e)
        {
            bool codeExists = false;
            int currentWeek;
            int workWeek;

            studies.studyDate = DateTime.Parse(DatePicker1.Text);
            studies.Code = tb2Code.Text;
            studies.hrsWorked = Convert.ToInt32(tbHrs.Text);
            foreach (Module m in course)
            {
                if (m.code == studies.Code)
                {
                    codeExists = true;
                }

            }
            if (codeExists == true)
            {
                studyData.Add(new Study { studyDate = studies.studyDate, Code = studies.Code, hrsWorked = studies.hrsWorked });


        
                DataGrid2.Items.Clear();
                // Displays the input from the user on the second datagrid
                foreach (Study s in studyData)
                {
                    DataGrid2.Items.Add(s);
                }
                // clears the textboxes
                tb2Code.Clear();
                tbHrs.Clear();
               
                currentWeek = Calculate.currentWeek(temp.startDate);
                workWeek = Calculate.workWeek(studies.studyDate, temp.startDate);
                if (currentWeek == workWeek)
                {
                    foreach (Module h in hours)
                    {
                       //calculation for self study hours and hours remaining
                        if (h.code == tb2Code.Text)
                        {
                            h.hoursSpentThisWeek = h.hoursSpentThisWeek + studies.hrsWorked;
                            h.hoursRemaining = h.hoursRemaining - studies.hrsWorked;
                        }

                    }
                    //displays the self study and hours remaining
                    DataGrid3.Items.Clear();
                    foreach (Module h in hours)
                    {
                        DataGrid3.Items.Add(h);
                    }
                }
            }
            // If the code does not match, this error message will pop up
            else
            {
                MessageBox.Show("This Code Does Not Exist");

            }
            
            
           

         
            

        }

        // Uses LINQ to order the hours remaining in descending order
        private void btnOrder_Click(object sender, RoutedEventArgs e)
        {
            filtered = hours.OrderByDescending(h => h.hoursRemaining).ToList();

            DataGrid3.Items.Clear();
            // adds the filtered items to the datagrid once the order button is clicked
            foreach (Module h in filtered)
            {
                DataGrid3.Items.Add(h);
            }
        }

        

    }
}